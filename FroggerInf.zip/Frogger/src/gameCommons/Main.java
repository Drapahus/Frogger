package gameCommons;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Timer;

import environment.EnvInf;
import environment.Environment;
import frog.Frog;
import frog.FrogInf;
import givenEnvironment.GivenEnvironment;
import graphicalElements.FroggerGraphic;
import graphicalElements.IFroggerGraphics;

public class Main {

	
	public static void main(String[] args) {

		//Caract�ristiques du jeu
		int width = 52;
		int height = 40;
		int tempo = 100;
		int minSpeedInTimerLoops = 3;
		double defaultDensity = 0.2;
		
		
		//Cr�ation de l'interface graphique
		IFroggerGraphics graphic = new FroggerGraphic(width, height);
		//Cr�ation de la partie
		Game game = new Game(graphic, width, height, minSpeedInTimerLoops, defaultDensity);
		//Cr�ation et liaison de la grenouille
		IFrog frog = new Frog(game);
		//IFrog frog=new FrogInf(game);
		
		game.setFrog(frog);
		graphic.setFrog(frog);
		//Cr�ation et liaison de l'environnement
		//IEnvironment env = new GivenEnvironment(game);
		//Creation et liaison de l�environnement
		IEnvironment env = new Environment(game);
		//IEnvironment env=new EnvInf(game);
		
		
		game.setEnvironment(env);
				
		game.timer = game.creerTimer();
		//Boucle principale : l'environnement s'actualise tout les tempo milisecondes
		game.timer = new Timer(tempo, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				game.update();
				graphic.repaint();
			}
		});
		game.timer.setInitialDelay(0);
		game.timer.start();
	}
	

}
