package gameCommons;

public class Case {
	public int absc;
	public int ord;
	
	public Case(int absc, int ord) {
		super();
		this.absc = absc;
		this.ord = ord;
	}

}
