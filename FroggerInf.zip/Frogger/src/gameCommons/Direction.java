package gameCommons;

public enum Direction {
	up, down, right, left ,
}
