package graphicalElements;

import javax.swing.*;

import gameCommons.Direction;
import gameCommons.IFrog;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

public class FroggerGraphic extends JPanel implements IFroggerGraphics, KeyListener {
	private ArrayList<Element> elementsToDisplay;
	private int pixelByCase = 16;
	private int width;
	private int height;
	
	private IFrog frog;
	private JFrame frame;

	public FroggerGraphic(int width, int height) {
		this.width = width;
		this.height = height;
		elementsToDisplay = new ArrayList<Element>();

		setBackground(Color.PINK);
		setPreferredSize(new Dimension(width * pixelByCase, height * pixelByCase));

		JFrame frame = new JFrame("Frogger");
		this.frame = frame;
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().add(this);
		frame.pack();
		frame.setVisible(true);
		frame.addKeyListener(this);
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		for (Element e : elementsToDisplay) {
			g.setColor(e.color);
			g.fillRect(pixelByCase * e.absc, pixelByCase * (height - 1 - e.ord), pixelByCase, pixelByCase - 1);
		}
	}

	public void keyTyped(KeyEvent e) {
	}

	public void keyReleased(KeyEvent e) {
	}

	public void keyPressed(KeyEvent e) {
		switch (e.getKeyCode()) {
		case KeyEvent.VK_UP:
			frog.moveInf(Direction.up);
			break;
		case KeyEvent.VK_DOWN:
			frog.moveInf(Direction.down);
			break;
		case KeyEvent.VK_LEFT:
			frog.moveInf(Direction.left);
			break;
		case KeyEvent.VK_RIGHT:
			frog.moveInf(Direction.right);
		}
	}

	public void clear() {
		this.elementsToDisplay.clear();
	}

	public void add(Element e) {
		this.elementsToDisplay.add(e);
	}

	public void setFrog(IFrog frog) {
		this.frog = frog;
	}

	public void endGameScreen(String s, int scoreMax) {
		//timer.stop();
		frame.remove(this);
		//String newLigne=System.getProperty("line.separator");
		JLabel label = new JLabel(s);
		label.setFont(new Font("Times New Roman", 5, 50));
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setSize(this.getSize());
		frame.getContentPane().add(label);
		
		
		frame.repaint();
		
		//frame.getContentPane().remove(label);
		JPanel test = new JPanel();
		
		JLabel lab=new JLabel("Score Max = " + scoreMax );
		lab.setFont(new Font("Times New Roman", 3, 30));
		lab.setHorizontalAlignment(SwingConstants.CENTER);
		lab.setVerticalAlignment(SwingConstants.BOTTOM);
		lab.setSize(this.getSize());
		//test.add(lab);
		frame.getContentPane().add(lab);
		frame.repaint();
		
	}

}
