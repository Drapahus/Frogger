package environment;

import java.awt.Color;

import gameCommons.Game;

public class River extends Environment{
	
	
	private Color color;
	
	public River(Game game) {
		super(game);
		this.color=new
	}



}
