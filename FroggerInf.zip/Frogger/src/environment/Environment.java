package environment;

import java.util.ArrayList;
import java.util.Random;

import gameCommons.Case;
import gameCommons.Direction;
import gameCommons.Game;
import gameCommons.IEnvironment;

public class Environment implements IEnvironment {
	
		private Game game;
		private ArrayList<Lane> lanes= new ArrayList<>();
		public static Random randomGen = new Random();
		private double dens;
		
		private final  int density=20;
		
		
	public Environment(Game game) {
		this.game=game;
		this.lanes.add(new Lane(game,0,0));
		for(int i=1;  i<this.game.height-1;i++) {
			dens=this.game.randomGen.nextDouble()/density;
			this.lanes.add(new Lane(game,i,dens));
		}
		this.lanes.add(new Lane(game,game.height-1,0));
		
		
		//Ce bout de code est pour avoir le jeu "lanc�"
		for(int i=0; i<5/2*this.game.width; i++) {
			for(Lane lane:this.lanes)
				lane.update();
		}
	}
	
	public boolean isSafe(Case c) {
		for(Lane lane : this.lanes) {
			if(!(lane.isSafe(c)))
				return false;
		}
		return true;
		
	}
	
	
	public boolean isWinningPosition(Case c) {
		return (c.ord==this.game.height);
	}

	public ArrayList<Lane> getLanes(){
		return this.lanes;
	}
	
	public void update() {
		for(Lane lane:this.lanes)
			lane.update();
	}
	//PARTIE 3
	
	public void laneAdd() {
		
		this.lanes.add(new Lane(this.game,this.game.height,this.game.randomGen.nextDouble()/density));
		for(int i=0;i<5/2*this.game.width;i++) {
			lanes.get(this.lanes.size()-1).update();
			
		}
		
		/*
		 * Score= Variable qui compte le nb de lignes franchies,( le nombre max ?) a impl�menter si on le fait comme �a 
		 */	
	}
	
	public void laneDel() {
		this.lanes.remove(0);// L'arrayList supprimera au fur et � mesure donc forc�ment premi�re position qu'on supprime
		
		//Pas encore utilis�e
	}
	
	public void tabLaneUpdate(){
		if(this.game.getFrog().getDirection()==Direction.up) {
			for(Lane lane : this.lanes ) {
				lane.updatePosLane();
			}
			this.game.setFrogNull();
		}
//	@Override
//	public void laneAdd() {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void laneDel() {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void tabLaneUpdate() {
//		// TODO Auto-generated method stub
//		
//	}
	}
}
