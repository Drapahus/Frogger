package environment;

import java.awt.Color;

import gameCommons.Case;
import gameCommons.Game;
import graphicalElements.Element;

public class Car {
	private Game game;
	private Case firstPosition;
	private boolean leftToRight;
	private int length;
	//private final Color colorLtR = Color.YELLOW;
	//private final Color colorRtL = Color.BLUE;
	private Color[] color= {Color.YELLOW,Color.BLUE,Color.RED,Color.DARK_GRAY,Color.ORANGE,Color.CYAN};
	private Color couleur;
	//TODO Constructeur(s)
	
	public Car (Game game, Case firstCase, boolean leftToRight){
		this.game=game;
		this.leftToRight=leftToRight;
		this.length=game.randomGen.nextInt(3)+1;
		this.firstPosition=firstCase;
		int numCouleur=this.game.randomGen.nextInt(this.color.length);
		this.couleur = this.color[numCouleur];
	}
	
	//TODO : ajout de methodes

	/*
	 * Avance la voiture dans la direcion/ sens
	 * correspondant
	 */
	public void move() {
			if(this.leftToRight) 
				this.firstPosition.absc++; //Changer en juste +1
			else 
				this.firstPosition.absc--;//chnager en -1
			this.addToGraphics();
		}
	
	/*
	 * Retourne le coordonn�es le plus � gauche
	 * de la voiture
	 */
	public Case leftPos() { //Prend Pas en compte la longueur de la voiture
		if(this.leftToRight)
			return new Case(this.firstPosition.absc-(length-1),this.firstPosition.ord);
		else
			return new Case(this.firstPosition.absc,this.firstPosition.ord);	
	}
	
	/*
	 * retourne lenght de la voiture
	 */
	public int carLength() {
		return this.length;
	}
	
	/*
	 * retourne la position "devant" de 
	 * la voiture
	 */
	public Case firstCase() {
		return this.firstPosition;
	}
	
	public Case lastCase() { //Prend Pas en compte la longueur de la voiture
		if(this.leftToRight)
			return new Case(this.firstPosition.absc-(length-1),this.firstPosition.ord);
		else
			return new Case(this.firstPosition.absc+(length-1),this.firstPosition.ord);	
	}

	/*
	 * retourn vraie/faux si la voiture
	 * va ver de gauche � droite
	 */
	public boolean leftToRight() {
		return this.leftToRight;
	}
	
	public void carUpdate() {
		
		//System.out.print(this.leftToRight);
//		move();
		this.addToGraphics();
		
	}
	
	
	//PARTIE 3
	
	public void carInf() { // Permet aux lanes de descendre, pas encore impl�menter la fonction pour redescendre apr�s 
		this.addToGraphics();
		this.firstPosition.ord--;
	//this.delToGraphics();
	}
	
	/* Fourni : addToGraphics() permettant d'ajouter un element graphique correspondant a la voiture*/
	private void addToGraphics() {
		for (int i = 0; i < length;i++) {
			game.getGraphic()
					.add(new Element(firstPosition.absc + i, firstPosition.ord, this.couleur));
		}
	}

}
