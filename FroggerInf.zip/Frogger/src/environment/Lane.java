package environment;

import java.util.ArrayList;

import gameCommons.Case;
import gameCommons.Game;

public class Lane {
	private Game game;
	private int ord;
	private float speed; 
	private ArrayList<Car> cars ;
	private boolean leftToRight;
	private double density;
	private float timer;
	
	
	public Lane(Game game,int i,double dens) {
		this.cars= new ArrayList<Car>();
		this.ord=i;
		this.game=game;
		this.density=dens;
		this.speed=game.randomGen.nextInt(10);
		this.leftToRight=game.randomGen.nextBoolean();
		//System.out.println(this.leftToRight);
		this.timer=0;
	}
	// TODO : Constructeur(s)
	
	public void update() {
		this.timer+=1;
		mayAddCar();
		removeCar();
		if(this.speed<=this.timer) {
			for(Car car:this.cars) {
				car.move();
				car.carUpdate();
			}
			this.timer=0;
		}
		else
			for(Car car : this.cars)
				car.carUpdate();
		
		// Toutes les voitures se d�placent d'une case au bout d'un nombre "tic
		// d'horloge" �gal � leur vitesse
		// Notez que cette m�thode est appel�e � chaque tic d'horloge

		// Les voitures doivent etre ajoutes a l interface graphique meme quand
		// elle ne bougent pas

		// A chaque tic d'horloge, une voiture peut �tre ajout�e

	}

	// TODO : ajout de methodes
	
	/*
	 * v�rifie si une case est "vide"
	 * Ya un bug avec les voitures qui vont de gauche � droite
	 */
	public boolean isSafe(Case c) { //A revoir pas s�r
		if( c.ord == this.ord  ) { //Erreur car on utilise isSafe pour la case suivante dcp pas la case actuelle
			for(Car car : this.cars) {//IL ya un bug lorsuqe les voitures vont de gauche � droite
				for(int i=0; i<car.carLength(); i++) {
					if(car.firstCase().absc+i==c.absc) return false;
				}
			}
		}
		return true;
	}
	
	/*
	 * Fonction qui v�rifie si une voiture est en dehors de l'�cran
	 * return boolean
	 */
	public boolean outOfScreen(int i) {
		return (this.cars.get(i).lastCase().absc>this.game.width+3) || (this.cars.get(i).lastCase().absc<-3);// 3 ou 2
	}
	
	
	/*
	 * enleve les voitures qui sont a l'ext�rieur de l'�cran
	 * 
	 * Am�lioration possible:
	 *  - utiliser l'arri�re de la voiture et non le devant=> C'est bon
	 *  - cot� droite vraimznt utiliser l'�cran
	 */
	public void removeCar() {
		int i=0;
		//System.out.println(this.cars.size());
		while (i<this.cars.size()) {
			if(outOfScreen(i)) 
				this.cars.remove(i);
			else
				i++;
			
		}
	}
	
	
	// PARTIE 3
	
	
	
	
	public void updatePosLane() {
		this.ord--;	
		for(Car car:this.cars) {
			car.carInf();
			//System.out.println(car.carPos().ord);
		}
	}

	/*
	 * Fourni : mayAddCar(), getFirstCase() et getBeforeFirstCase() 
	 */

	/**
	 * Ajoute une voiture au d�but de la voie avec probabilit� �gale � la
	 * densit�, si la premi�re case de la voie est vide
	 */
	private void mayAddCar() {
		if (isSafe(getFirstCase()) && isSafe(getBeforeFirstCase())) {
			if (game.randomGen.nextDouble() < density) {
				//System.out.println(leftToRight);
				cars.add(new Car(game, getBeforeFirstCase(), leftToRight));
			}
		}
		
	}

	private Case getFirstCase() {
		if (this.leftToRight) {
			return new Case(0, this.ord);
		} else
			return new Case(game.width - 1, this.ord);
	}

	private Case getBeforeFirstCase() {
		if (this.leftToRight) {
			return new Case(-1, this.ord);
		} else
			return new Case(game.width, this.ord);
	}

}
