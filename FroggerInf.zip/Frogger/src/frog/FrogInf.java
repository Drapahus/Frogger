
package frog;

import gameCommons.Game;

public class FrogInf extends Frog{

	public FrogInf(Game game) {
		super(game);
	}

	public void setDirectionNull() {
		this.direction=null;
		
	}
	
}
